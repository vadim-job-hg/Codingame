import java.util.*;

class Solution {
  public static void main(String args[]) {
    // Read the game info
    Scanner in = new Scanner(System.in);
    int width = in.nextInt();
    int height = in.nextInt();

    Board board = new Board(height, width);

    for (int y = 0; y < height; ++y) {
      String row = in.next();
      for (int x = 0; x < width; ++x) {
        char c = row.charAt(x);
        Cell cell = board.grid[y][x];
        cell.c = c;
        if (c == Cell.START)
          board.start = cell;
      } // for
    } // for

    bfs(board);
  } // main()

  static void bfs(Board board) {
    Queue<Cell> queue = new LinkedList<>();
    Cell current;
    board.start.isMarked = true;
    queue.add(board.start);

    while (!queue.isEmpty()) {
      current = queue.remove();
      for (Cell neighbor : board.neighbors(current)) {
        neighbor.isMarked = true;
        neighbor.prev = current;
        if (neighbor.c == Cell.FINISH) {
          Stack<Cell> path = new Stack<>();
          path.push(neighbor);
          while (!neighbor.prev.equals(board.start)) {
            neighbor = neighbor.prev;
            path.push(neighbor);
          } // while
          System.out.println(path.size());
          return;
        } else {
          queue.add(neighbor);
        } // else
      } // for
    } // while
    System.out.println("Impossible");
  } // bfs()
} // Solution

class Board {
  Cell[][] grid;
  Cell start; // for BFS
  int height, width;

  Board(int height, int width) {
    this.height = height; // y
    this.width = width; // x
    grid = new Cell[height][width]; // [y][x]

    for (int y = 0; y < height; ++y)
      for (int x = 0; x < width; ++x)
        grid[y][x] = new Cell(x, y);
  } // Maze()

  // at most 8 options around the knight
  ArrayList<Cell> neighbors(Cell cell) {
    ArrayList<Cell> list = new ArrayList<>();
    int x = cell.x + 2;
    int y = cell.y + 1;
    add(list, x, y);

    x = cell.x + 1;
    y = cell.y + 2;
    add(list, x, y);

    x = cell.x - 1;
    y = cell.y + 2;
    add(list, x, y);

    x = cell.x - 2;
    y = cell.y + 1;
    add(list, x, y);

    // next 4
    x = cell.x - 2;
    y = cell.y - 1;
    add(list, x, y);

    x = cell.x - 1;
    y = cell.y - 2;
    add(list, x, y);

    x = cell.x + 1;
    y = cell.y - 2;
    add(list, x, y);

    x = cell.x + 2;
    y = cell.y - 1;
    add(list, x, y);

    return list;
  } // neighbors()

  void add(ArrayList<Cell> list, int x, int y) {
    if (isValid(x, y)) {
      Cell cell = grid[y][x];
      if (isValid(cell) && !cell.isMarked)
        list.add(cell);
    } // if
  } // add()

  boolean isValid(int x, int y) {
    return 0 <= x && x < width &&
           0 <= y && y < height;
  } // isValid()

  boolean isValid(Cell cell) {
    return (cell.c != Cell.WALL); // avoid walls
  } // isValid()
} // Maze

class Cell {
  // Possible types of cells
  final static char WALL = '#';
  final static char START = 'B';
  final static char FINISH = 'E';

  // for BFS
  Cell prev;
  boolean isMarked;

  char c; // type of the cell
  int x, y; // coordinates

  Cell(int x, int y) {
    this.x = x;
    this.y = y;
  } // Cell()

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Cell) {
      Cell cell = (Cell) obj;
      return (x == cell.x) && (y == cell.y);
    } // if
    return false;
  } // equals()
} // Cell