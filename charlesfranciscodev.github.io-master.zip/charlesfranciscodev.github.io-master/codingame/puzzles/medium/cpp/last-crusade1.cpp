#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

void printNextRoom(int type, int x, int y, string entrance);

int main() {
  vector<vector<int>> rooms;
  int nbColumns; // number of columns
  int nbRows; // number of rows

  cin >> nbColumns >> nbRows; cin.ignore();
  rooms.resize(nbRows);

  for (int i = 0; i < nbRows; ++i) {
    rooms[i].resize(nbColumns);
    string line; // represents a line in the grid. Each integer represents one room of a given type.
    string element;
    getline(cin, line);
    stringstream lineStream(line);
    int j = 0;
    while (getline(lineStream, element, ' ')) {
      rooms[i][j] = stoi(element);
      ++j;
    }
  }

  cerr << "Rooms" << endl;
  for (int i = 0; i < nbRows; ++i) {
    for (int j = 0; j < nbColumns; ++j) {
      cerr << rooms[i][j] << " ";
    }
    cerr << endl;
  }

  int exit; // the coordinate along the X axis of the exit (not useful but must be read).
  cin >> exit; cin.ignore();

  cerr << "Current room" << endl;

  // game loop
  while (1) {
    int x, y;
    string entrance;
    cin >> x >> y >> entrance; cin.ignore();
    cerr << y << " " << x << " " << entrance << endl;

    printNextRoom(rooms[y][x], x, y, entrance);
  }
}

void printNextRoom(int type, int x, int y, string entrance) {
  const string TOP = "TOP";
  const string LEFT = "LEFT";
  const string RIGHT = "RIGHT";

  cerr << type << endl;

  switch (type) {
    case 2:
    case 6:
      (entrance.compare(LEFT) == 0) ? ++x : --x; break;
    case 4: (entrance.compare(TOP) == 0) ? --x : ++y; break;
    case 5: (entrance.compare(TOP) == 0) ? ++x : ++y; break;
    case 10: --x; break;
    case 11: ++x; break;
    default: ++y; // go down
  }

  // X Y coordinates of the room in which you believe Indy will be on the next turn.
  cout << x << " " << y << endl;
}