import java.util.*;

class Solution {
  public static void main(String args[]) {
    final String YES = "Yes";
    final String NO = "No";
    Scanner in = new Scanner(System.in);
    int nbVoters = in.nextInt();
    int totalVotes = in.nextInt();

    Map<String, Integer> map = new HashMap<>();
    for (int i = 0; i < nbVoters; i++) {
      String personName = in.next();
      int nbVotes = in.nextInt();
      map.put(personName, nbVotes);
    } // for

    // Filter the results
    List<Pair> results = new ArrayList<>();
    for (int i = 0; i < totalVotes; i++) {
      String voterName = in.next();
      String voteValue = in.next();
      // Check if the voter exists
      if (map.containsKey(voterName)) {
        // Check if the voter did not over vote
        int nbVotes = map.get(voterName);
        if (nbVotes != 0) {
          // Check if vote is either Yes or No
          if (voteValue.equals(YES) || voteValue.equals(NO)) {
            map.put(voterName, nbVotes - 1);
            results.add(new Pair(voterName, voteValue));
          } // if
        } else {
          // Invalid all his votes
          map.remove(voterName);
          results.removeIf(pair -> pair.isVoter(voterName));
        } // else
      } // if
    } // for

    // Count the results
    int yesCount = 0;
    int noCount = 0;
    for (Pair pair : results) {
      if (pair.voteValue.equals(YES))
        ++yesCount;
      else
        ++noCount;
    } // for

    System.out.println(yesCount + " " + noCount);
  } // main()
} // Solution

class Pair {
  String voterName;
  String voteValue;

  public Pair(String voterName, String voteValue) {
    this.voterName = voterName;
    this.voteValue = voteValue;
  }

  boolean isVoter(String voterName) {
    return this.voterName.equals(voterName);
  }
}