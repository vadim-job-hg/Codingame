let year = new Date().getFullYear();
let content = "&copy; " + year;
$("#copyright").append(content);
