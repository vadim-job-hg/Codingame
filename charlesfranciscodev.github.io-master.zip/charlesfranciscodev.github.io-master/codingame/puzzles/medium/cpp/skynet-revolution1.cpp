#include <iostream>
#include <string>
#include <list>
#include <algorithm>

using namespace std;

class Link {
  public:
    int n1, n2;

    Link(int node1, int node2) : n1(node1), n2(node2) {}
};

bool equals(Link link1, Link link2) {
  return ((link1.n1 == link2.n1) && (link1.n2 == link2.n2)) ||
         ((link1.n1 == link2.n2) && (link1.n2 == link2.n1));
}

// sever the link
void slice(Link link) {
  cout << link.n1 << " " << link.n2 << endl;
}

int main() {
  list<Link> graph;
  list<int> gateways;
  int nbNodes; // total number of nodes in the level, including the gateways
  int nbLinks; // number of links
  int nbExits; // number of exit gateways
  cin >> nbNodes >> nbLinks >> nbExits; cin.ignore();
  cerr << nbNodes << " " << nbLinks << " " << nbExits << endl;

  for (int i = 0; i < nbLinks; ++i) {
    int n1, n2; // n1 and n2 defines a link between these nodes
    cin >> n1 >> n2; cin.ignore();
    Link link(n1, n2);
    graph.push_back(link);
  }

  cerr << "Links" << endl;
  for (Link link : graph) {
    cerr << link.n1 << " " << link.n2 << endl;
  }

  for (int i = 0; i < nbExits; ++i) {
    int exit; // index of a gateway node
    cin >> exit; cin.ignore();
    gateways.push_back(exit);
  }

  cerr << "Gateways" << endl;
  for (int exit : gateways) {
    cerr << exit << endl;
  }

  // game loop
  while (1) {
    int agentNode; // node on which the Skynet agent is positioned this turn
    cin >> agentNode; cin.ignore();

    // block a nearby agent
    bool sever = false;
    list<int>::const_iterator exit;
    list<Link>::const_iterator link;
    for (exit = gateways.begin(); (exit != gateways.end()) && !sever; ++exit) {
      Link exitLink(agentNode, *exit);
      for (link = graph.begin(); (link != graph.end()) && !sever; ++link) {
        if (equals((*link), exitLink)) {
          cerr << "block a nearby agent" << endl;
          slice((*link));
          graph.erase(link);
          sever = true;
        }
      }
    }

    // block a random link
    if (!sever) {
      if (!graph.empty()) {
        cerr << "block a random link" << endl;
        Link backLink = graph.back();
        slice(backLink);
        graph.pop_back();
      }
    }
  }
}