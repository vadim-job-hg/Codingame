#include <iostream>
#include <string>
#include <vector>
#include <ctype.h>

using namespace std;

int main() {
  const int ALPHABET_SIZE = 27;
  int width; // the width of a letter represented in ASCII art
  int totalWidth; // alphabetWidth
  int height; // the height of a letter represented in ASCII art
  string text; // text to be displayed
  vector<string> asciiArt;

  cin >> width; cin.ignore();
  cin >> height; cin.ignore();
  getline(cin, text);
  totalWidth = width * ALPHABET_SIZE;

  for (int i = 0; i < height; ++i) {
    string row;
    getline(cin, row);
    asciiArt.push_back(row);
  }

  // Debug
  for (int i = 0; i < height; ++i) {
    for (int j = 0; j < totalWidth; ++j) {
      cerr << asciiArt[i][j];
    }
    cerr << endl;
  }

  // Prints the letter for every height level
  int position; // position in the alphabet
  int column; // starting column in the ascii art vector
  for (int i = 0; i < height; ++i) {
    for (int j = 0; j < text.length(); ++j) {
      position = toupper(text[j]) - 'A';
      if (position < 0 || position > 25) {
        position = 26;
      }
      column = position * width;
      for (int k = column; k < (column + width); ++k) {
        cout << asciiArt[i][k];
      }
    }
    cout << endl;
  }
}