import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    String unary = in.nextLine();
    String binary = toBinary(unary);
    System.err.println(binary);
    String ascii = toAscii(binary);
    System.out.println(ascii);
  }

  static String toBinary(String unary) {
    String binary = "";
    String[] array = unary.split(" ");
    boolean digit = false; // false -> 0, true -> 1
    for (int i = 0; i < array.length; ++i) {
      String s = array[i];
      if (i % 2 == 0) {
        // first sequence
        if (s.equals("00")) {
          digit = false;
        } else if (s.equals("0")) {
          digit = true;
        } else {
          System.out.println("INVALID");
          System.exit(0);
        }
      } else {
        // second sequence
        char c = digit ? '1' : '0';
        for (int j = 0; j < s.length(); ++j) {
          if (s.charAt(j) != '0') {
            System.out.println("INVALID");
            System.exit(0);
          }
          binary += c;
        }
      }
    }
    return binary;
  }

  static String toAscii(String binary) {
    final int LENGTH = 7;
    String ascii = "";

    if (binary.length() % 7 != 0) {
      System.out.println("INVALID");
      System.exit(0);
    }

    for (int i = 0; i < binary.length(); i += LENGTH) {
      String sub = binary.substring(i, i + LENGTH);
      int x = Integer.parseInt(sub, 2);
      char c = (char) x;
      ascii += c;
    }
    return ascii;
  }
}
