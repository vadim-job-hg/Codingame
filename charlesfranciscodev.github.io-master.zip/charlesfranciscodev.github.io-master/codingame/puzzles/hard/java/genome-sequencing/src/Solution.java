import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    int nbSubSeq = in.nextInt(); // number of sub sequences
    ArrayList<String> subSeqList = new ArrayList<>(nbSubSeq);
    for (int i = 0; i < nbSubSeq; ++i) {
      String subseq = in.next();
      subSeqList.add(subseq);
    } // for

    LinkedList<ArrayList<String>> combos = generate(subSeqList, nbSubSeq);

    System.out.println(shortestSeqLen(combos));
  } // main()

  // Generate all potential combinations
  static LinkedList<ArrayList<String>> generate(ArrayList<String> original, int nbSubSeq) {
    LinkedList<ArrayList<String>> combos = new LinkedList<>();
    ArrayList<Integer> indexes = new ArrayList<>(nbSubSeq);
    for (int j = 0; j < nbSubSeq; ++j) {
      indexes.add(0);
    } // for
    combos.add(original);

    int i = 0;
    ArrayList<String> combo = new ArrayList<>(original);
    while (i < nbSubSeq) {
      if (indexes.get(i) < i) {
        if (i % 2 == 0) {
          Collections.swap(combo, 0, i);
        } else {
          Collections.swap(combo, indexes.get(i), i);
        } // else
        combos.add(combo);
        combo = new ArrayList<>(combo);
        indexes.set(i, indexes.get(i) + 1);
        i = 0;
      } else {
        indexes.set(i, 0);
        ++i;
      } // else
    } // while

    return combos;
  } // generate()

  // Determine the shortest possible sequence length
  static int shortestSeqLen(LinkedList<ArrayList<String>> combos) {
    int shortestLen = Integer.MAX_VALUE;
    for (ArrayList<String> current : combos) {
      for (String s : current)
        System.err.print(s + " ");

      int currentLen = len(current);
      System.err.println(currentLen);
      if (currentLen < shortestLen)
        shortestLen = currentLen;
    } // for
    return shortestLen;
  } // shortestSeqLen()

  static int len(ArrayList<String> combo) {
    int len = 0;
    int prevLen = 0;

    if (combo.stream().allMatch(s -> s.equals(combo.get(0))))
      return combo.get(0).length();

    if ((combo.size() == 3) &&
        combo.get(0).contains(combo.get(1)) &&
        combo.get(0).contains(combo.get(2))) {
      return combo.get(0).length();
    } // if

    for (int i = 0; i < (combo.size() - 1); ++i) {
      String current = combo.get(i);
      String next = combo.get(i + 1);

      if (current.contains(next)) {
        prevLen = current.length();
        len += prevLen;
      } else if (next.contains(current)) {
        prevLen = next.length();
        len += prevLen;
      } else {
        int j;
        for (j = 0; j < current.length(); ++j) {
          String subCur = current.substring(j);
          String subNext = next.substring(0, Math.min(subCur.length(), next.length()));
          if (subCur.equals(subNext)) {
          if (i == 0) {
            len += current.length() + next.length() - subNext.length();
          } else {
            len += next.length() - subNext.length();
          } // else
          break;
          } // if
        } // for
        // if no substrings were found
        if (j == current.length())
          len += prevLen == 0 ? current.length() + next.length() : next.length();
      } // else
    } // for
    return len;
  } // len()
} // Solution