#include <iostream>
#include <bitset>

using namespace std;

string toBinary(string);
string toUnary(string);

int main() {
  string msg;
  getline(cin, msg);
  string binary = toBinary(msg);
  cout << toUnary(binary) << endl;
}

// Convert the string into its binary representation
string toBinary(string msg) {
  string binaryMsg = "";
  for (int i = 0; i < msg.length(); ++i) {
    binaryMsg += bitset<7>(msg.at(i)).to_string();
  }
  return binaryMsg;
}

// Convert the string into its unary representation
string toUnary(string msg) {
  string unaryMsg = "";
  bool digit = false; // false = 0, true = 1
  char c;

  // first character
  if (msg.length() >= 1) {
    c = msg.at(0);
    if (c == '0') {
      unaryMsg += "00 0"; // New sequence of zeros
    } else {
      unaryMsg += "0 0"; // New sequence of ones
      digit = true;
    }
  }

  for (int i = 1; i < msg.length(); ++i) {
    c = msg.at(i);
    if ((c == '0') && digit) { // Switch from 1 to 0
      unaryMsg += " 00 0";
      digit = false;
    } else if ((c == '1') && !digit) { // Switch from 0 to 1
      unaryMsg += " 0 0";
      digit = true;
    } else { // Repeated 0 or 1
      unaryMsg += "0";
    }
  }
  return unaryMsg;
}