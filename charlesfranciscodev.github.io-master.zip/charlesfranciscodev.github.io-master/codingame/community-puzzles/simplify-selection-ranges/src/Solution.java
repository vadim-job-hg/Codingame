import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    String input = in.nextLine();
    System.err.println(input);
    String temp = input.substring(1, input.length() - 1);
    String[] array = temp.split(",");
    List<Integer> list = new ArrayList<>();
    for (String s : array)
      list.add(Integer.parseInt(s));
    Collections.sort(list);

    String output = "";
    int currentValue;
    int nextValue;
    int streak = 0;
    int beginIndex = 0;
    int endIndex = 0;
    for (int i = 0; i < list.size() - 1; ++i) {
      currentValue = list.get(i);
      nextValue = list.get(i + 1);
      if (currentValue + 1 == nextValue) {
        ++streak;
        endIndex = i + 1;
      } else {
        if (streak >= 2) {
          output += list.get(beginIndex) + "-" + list.get(endIndex) + ",";
        } else if (streak == 1) {
          output += list.get(i - 1) + "," + list.get(i) + ",";
        } else {
          output += list.get(i) + ",";
        } // else
        beginIndex = i + 1;
        streak = 0;
      } // else
    } // for

    // last value
    int lastIndex = list.size() - 1;
    currentValue = list.get(lastIndex);
    if (streak >= 2) {
      output += list.get(beginIndex) + "-" + list.get(endIndex);
    } else if (streak == 1) {
      output += list.get(lastIndex - 1) + "," + list.get(lastIndex);
    } else {
      output += list.get(lastIndex);
    } // else

    System.out.println(output);
  } // main()
} // Solution