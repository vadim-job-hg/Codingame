import operator


class Task:
    def __init__(self, start_day, duration):
        self.start_day = start_day
        self.end_day = start_day + duration - 1


reservation_list = []
nb_calculations = int(input())
for i in range(nb_calculations):
    start_day, duration = [int(j) for j in input().split()]
    task = Task(start_day, duration)
    reservation_list.append(task)

reservation_list.sort(key=operator.attrgetter("end_day"))

carry_list = []
carry_list.append(reservation_list[0])
prev_index = 0
for i in range(1, nb_calculations):
    task = reservation_list[i]
    prev_task = reservation_list[prev_index]
    if task.start_day > prev_task.end_day:  # check if task doesn't overlap
        carry_list.append(task)
        prev_index = i

print(len(carry_list))
