#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <math.h>

#define EARTH_RADIUS 6371
#define NAME 1
#define LONGITUDE 4
#define LATITUDE 5

using namespace std;

double to_radians(string);

int main() {
  double minimum = numeric_limits<double>::max();
  string name = "";
  string longitude, latitude;
  double lon, lat;
  int defibCount;

  cin >> longitude; cin.ignore();
  cin >> latitude; cin.ignore();
  cin >> defibCount; cin.ignore();

  lon = to_radians(longitude);
  lat = to_radians(latitude);

  for (int i = 0; i < defibCount; i++) {
    vector<string> defibVector;
    string defib, element;
    double defibLon, defibLat, x , y, distance;

    getline(cin, defib);
    stringstream defibStream(defib);

    while (getline(defibStream, element, ';')) {
      defibVector.push_back(element);
    }

    /* debug
    for (auto& elem : defibVector)
      cerr << elem << endl;
    cerr << endl;
    */

    defibLon = to_radians(defibVector[LONGITUDE]);
    defibLat = to_radians(defibVector[LATITUDE]);
    x = (defibLon - lon) * (cos((lat + defibLat) / 2));
    y = defibLat - lat;
    distance = hypot(x, y) * EARTH_RADIUS;
    if (distance < minimum) {
      minimum = distance;
      name = defibVector[NAME];
    }
  }

  cout << name << endl;
}

// Convert degrees to radians
double to_radians(string degrees) {
  // replace comma by dot
  for (int i = 0; i < degrees.length(); ++i) {
    if (degrees[i] == ',') {
      degrees[i] = '.';
    }
  }
  return stod(degrees) * M_PI / 180;
}