import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    // Candidates info
    int nbCandidates = in.nextInt();
    in.nextLine();
    HashMap<Integer, String> candidates = new HashMap<>();
    for (int i = 1; i <= nbCandidates; ++i) {
      String name = in.nextLine();
      candidates.put(i, name);
    } // for

    // Voters info
    int nbVoters = in.nextInt();
    in.nextLine();
    List<LinkedList<Integer>> voters = new ArrayList<>();
    for (int i = 0; i < nbVoters; i++) {
      String votes = in.nextLine();
      String[] array = votes.split(" ");
      LinkedList<Integer> list = new LinkedList<>();
      for (String s : array) {
        list.add(Integer.parseInt(s));
      }
      voters.add(list);
    } // for

    // Eliminate candidates
    while (candidates.size() > 1) {
      // Count the number of votes
      ArrayList<Integer> voteCount = new ArrayList<>(nbCandidates + 1);
      for (int i = 0; i <= nbCandidates; ++i)
        voteCount.add(0);
      for (LinkedList<Integer> voter : voters) {
        int vote = voter.getFirst();
        voteCount.set(vote, voteCount.get(vote) + 1);
      } // for

      // Determine the loser
      int minVotes = Integer.MAX_VALUE;
      int loser = 0;
      for (Integer candidate : candidates.keySet()) {
        int nbVotes = voteCount.get(candidate);
        if (nbVotes < minVotes) {
          minVotes = nbVotes;
          loser = candidate;
        } // if
      } // for

      // Announce the loser of this round
      System.out.println(candidates.get(loser));
      candidates.remove(loser);
      // Remove all the votes for the loser
      for (LinkedList<Integer> voter : voters) {
        int loserCopy = loser;
        voter.removeIf(vote -> vote.equals(loserCopy));
      } // for
      // Reset the voteCount
      for (int i = 0; i <= nbCandidates; ++i)
        voteCount.set(i, 0);
    } // while

    Integer winnnerKey = (Integer) candidates.keySet().toArray()[0];
    System.out.println("winner:" + candidates.get(winnnerKey));
  } // main()
} // Solution