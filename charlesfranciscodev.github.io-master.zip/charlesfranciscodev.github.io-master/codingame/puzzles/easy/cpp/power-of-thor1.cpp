#include <iostream>

using namespace std;

int main()
{
  int remainingTurns; // The remaining amount of turns Thor can move. Do not remove this line.
  int lightX; // the X position of the light of power
  int lightY; // the Y position of the light of power
  int initialTX; // Thor's starting X position
  int initialTY; // Thor's starting Y position
  cin >> lightX >> lightY >> initialTX >> initialTY; cin.ignore();

  // game loop
  while (1) {
    cin >> remainingTurns; cin.ignore();

    if ((initialTX < lightX) && (initialTY < lightY)) {
      // A single line providing the move to be made: N NE E SE S SW W or NW
      cout << "SE" << endl; // Move diagonally
      initialTX += 1;
      initialTY += 1;
    } else if ((initialTX > lightX) && (initialTY < lightY)) {
      cout << "SW" << endl;
      initialTX -= 1;
      initialTY += 1;
    } else if ((initialTX < lightX) && (initialTY > lightY)) {
      cout << "NE" << endl;
      initialTX += 1;
      initialTY -= 1;
    } else if ((initialTX > lightX) && (initialTY > lightY)) {
      cout << "NW" << endl;
      initialTX -= 1;
      initialTY -= 1;
    } else if (initialTX < lightX) {
      cout << "E" << endl; // Move horizontally
      initialTX += 1;
    } else if (initialTX > lightX) {
      cout << "W" << endl;
      initialTX -= 1;
    } else if (initialTY < lightY) {
      cout << "S" << endl;
      initialTY += 1;
    } else {
      cout << "N" << endl;
      initialTY -= 1;
    }
  }
}