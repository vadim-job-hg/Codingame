import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    int nbPeople = in.nextInt();
    in.nextLine();

    Stack<String> tree = new Stack<>(); // partial family tree
    for (int i = 0; i < nbPeople; i++) {
      String line = in.nextLine();
      String name = line.replaceAll("\\.", "");
      int nameLevel = line.length() - name.length();
      int treeLevel = tree.size();
      if (nameLevel == 0) {
        if (!tree.isEmpty()) {
          print(tree);
          tree.clear();
        } // if
      } else if (nameLevel < treeLevel) {
        print(tree);
        while (nameLevel < tree.size())
          tree.pop();
      } // else if
      tree.push(name);
    } // for

    print(tree);
  } // main()

  static void print(Stack<String> tree) {
    if (!tree.isEmpty()) {
      int i = 0;
      while (i < (tree.size() - 1)) {
        System.out.print(tree.get(i) + " > ");
        ++i;
      } // while
      System.out.println(tree.get(i));
    } // if
  } // print()
} // Solution