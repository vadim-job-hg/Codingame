#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
  int nbFloors; // number of floors
  int width; // width of the area
  int nbRounds; // maximum number of rounds
  int exitFloor; // floor on which the exit is found
  int exitPos; // position of the exit on its floor
  int nbTotalClones; // number of generated clones
  int nbAdditionalElevators; // ignore (always zero)
  int nbElevators; // number of elevators
  cin >> nbFloors >> width >> nbRounds >> exitFloor >> exitPos >> nbTotalClones >> nbAdditionalElevators >> nbElevators; cin.ignore();

  vector<int> elevators(nbFloors);

  for (int i = 0; i < nbElevators; ++i) {
    int elevatorFloor; // floor on which this elevator is found
    int elevatorPos; // position of the elevator on its floor
    cin >> elevatorFloor >> elevatorPos; cin.ignore();
    elevators[elevatorFloor] = elevatorPos;
  }

  // For the last floor, we use the exit instead of an elevator.
  elevators[nbFloors - 1] = exitPos;

  // game loop
  while (1) {
    int cloneFloor; // floor of the leading clone
    int clonePos; // position of the leading clone on its floor
    string direction; // direction of the leading clone: LEFT or RIGHT
    cin >> cloneFloor >> clonePos >> direction; cin.ignore();

    if (cloneFloor == -1) {
      cout << "WAIT" << endl;
    } else if (direction == "LEFT" && clonePos < elevators[cloneFloor]) {
      cout << "BLOCK" << endl;
    } else if (direction == "RIGHT" && clonePos > elevators[cloneFloor]) {
      cout << "BLOCK" << endl;
    } else {
      cout << "WAIT" << endl;
    }
  }
}