#include <iostream>

using namespace std;

int main() {
  int indexMax = -1;
  int max = -1;
  int mountainH; // represents the height of one mountain, from 9 to 0.

  // game loop
  while (1) {
    indexMax = -1;
    max = -1;

    for (int i = 0; i < 8; i++) {
      cin >> mountainH; cin.ignore();
      if (mountainH > max) {
        max = mountainH;
        indexMax = i;
      }
    }

    cout << indexMax << endl; // The number of the mountain to fire on.
  }
}