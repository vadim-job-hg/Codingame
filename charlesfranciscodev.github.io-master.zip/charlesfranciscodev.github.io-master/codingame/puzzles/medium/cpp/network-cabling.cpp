#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
  int minX = 0;
  int maxX = 0;
  long minCableSize;
  int n; // number of buildings
  cin >> n; cin.ignore();
  vector<int> coordinates(n);

  for (int i = 0; i < n; i++) {
    int x, y; // coordinates x and y of the buildings
    cin >> x >> y; cin.ignore();
    coordinates[i] = y;
    if (i == 0) {
      minX = maxX = x;
    } else if (x < minX) {
      minX = x;
    } else if (x > maxX) {
      maxX = x;
    }
  }

  sort(coordinates.begin(), coordinates.end());

  minCableSize = maxX - minX; // main horizontal cable length

  // To minimize the total vertical length of the cables,
  // the y value of the main cable must be the median of all the y values.
  int median = coordinates[n / 2];
  for (vector<int>::size_type i = 0; i != coordinates.size(); ++i) {
    minCableSize += (int) abs(median - coordinates[i]);
  }

  cout << minCableSize << endl;
}