#include <iostream>
#include <string>
#include <algorithm>
#include <unordered_map>

using namespace std;

int main() {
  const string UNKNOWN = "UNKNOWN";
  unordered_map<string, string> hash;
  string fileExt; // file extension
  int pairCount; // Number of elements which make up the association table.
  int fileCount; // Number of file names to be analyzed.
  string::size_type dotIndex;
  cin >> pairCount; cin.ignore();
  cin >> fileCount; cin.ignore();

  for (int i = 0; i < pairCount; i++) {
    string extension; // file extension
    string mimeType;
    cin >> extension >> mimeType; cin.ignore();
    transform(extension.begin(), extension.end(), extension.begin(), ::tolower);
    hash[extension] = mimeType;
  }

  /* Debug
  for (auto itr: hash)
    cerr << itr.first << " : " << itr.second << endl;
  */

  for (int i = 0; i < fileCount; i++) {
    string fileName; // One file name per line.
    getline(cin, fileName);
    dotIndex = fileName.find_last_of('.');
    //cerr << fileName << " " << dotIndex << " " << fileName.length() << endl;
    if (dotIndex >= fileName.length()) {
      cout << UNKNOWN << endl;
    } else {
      fileExt = fileName.substr(dotIndex + 1, std::string::npos);
      transform(fileExt.begin(), fileExt.end(), fileExt.begin(), ::tolower);
      //cerr << fileExt << endl;
      try {
        cout << hash.at(fileExt) << endl;
      } catch (const out_of_range& oor) {
        cout << UNKNOWN << endl;
      } // catch
    } // if
  } // for
} // main()