#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <iterator>

using namespace std;

int main() {
  int n; // the number of temperatures to analyse
  string input; // the n temperatures expressed as integers ranging from -273 to 5526
  int closestToZero = 0;
  int positiveValue = 0;
  int minimum = 5527;
  bool valueSign = true;
  bool minimumSign = true;

  // Read the temperature data
  cin >> n; cin.ignore();
  getline(cin, input);

  // Convert the input string of temperatures into and array
  istringstream buf(input);
  istream_iterator<int> beg(buf), end;
  vector<int> temps(beg, end);

  if (n == 0) {
    cout << n << endl; // debug
  } else {
    for (auto& temp: temps) {
      cerr << temp << endl;

      // Save the value sign
      if (temp < 0) {
        positiveValue = -temp;
        valueSign = false; // negative
      } else {
        positiveValue = temp;
        valueSign = true; // positive
      }

      // Determine the minimum temperature and it's sign
      if (positiveValue < minimum) {
        minimum = positiveValue;
        minimumSign = valueSign;
      } else if (positiveValue == minimum) {
        if (!minimumSign && valueSign)
          minimumSign = true;
      } // else if
    } // for

    // Go back to the original sign for display
    if (!minimumSign)
      minimum *= -1;
    cout << minimum << endl;
  } // else
} // main()