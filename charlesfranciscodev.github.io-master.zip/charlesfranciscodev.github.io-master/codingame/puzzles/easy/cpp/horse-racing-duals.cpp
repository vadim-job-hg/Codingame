#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
  int nbHorses; // number of horses
  int strength; // the strength of one horse
  int difference; // the difference in strength between two horses
  int minimum = numeric_limits<int>::max(); // // the smallest difference
  vector<int> strengthVector;

  cin >> nbHorses; cin.ignore();
  for (int i = 0; i < nbHorses; i++) {
    cin >> strength; cin.ignore();
    strengthVector.push_back(strength);
  }

  sort(strengthVector.begin(), strengthVector.end());

  for (vector<int>::size_type i = 1; i != strengthVector.size(); ++i) {
    //cerr << strengthVector[i] << endl;
    difference = strengthVector[i] - strengthVector[i - 1];
    if (difference < minimum) {
      minimum = difference;
    }
  }

  cout << minimum << endl;
}