import sys

light_x, light_y, thor_x, thor_y = [int(i) for i in input().split()]

# game loop
while True:
    remaining_turns = int(input())
    direction = ""

    if thor_y > light_y:
        direction += "N"
        thor_y -= 1
    elif thor_y < light_y:
        direction += "S"
        thor_y += 1

    if thor_x > light_x:
        direction += "W"
        thor_x -= 1
    elif thor_x < light_x:
        direction += "E"
        thor_x += 1

    # A single line providing the move to be made: N NE E SE S SW W or NW
    print(direction)
