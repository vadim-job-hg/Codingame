import java.util.*;

class Solution {
  public static void main(String args[]) {
    Bag bag = new Bag();
    Scanner in = new Scanner(System.in);
    int N = in.nextInt();
    for (int i = 0; i < N; i++) {
      int level = in.nextInt();
      bag.add(level);
    } // for

    while (bag.combine()) {}

    System.out.println(bag.size());
  } // main()
} // Solution

class Bag {
  List<Integer> stones = new ArrayList<>();

  void add(int level) {
    stones.add(level);
  } // add()

  int size() {
    return stones.size();
  } // size()

  boolean combine() {
    boolean update = false;
    Map<Integer, Integer> map = new HashMap<>(); // level and count
    for (int i = 0; i < size(); ++i) {
     Integer level = stones.get(i);
      if (!map.containsKey(level) || map.get(level) == 0) {
        map.put(level, 1);
      } else {
        update = true;
        stones.add(level + 1); // combine the two stones
        // update the list and the map
        stones.remove(i);
        stones.remove(level);
        map.put(level, 0);
      } // else
    } // for
    return update;
  } // combine()
} // Bag