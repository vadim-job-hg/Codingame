# charlesfranciscodev.github.io

My personal website. It contains my portfolio and solutions to CodinGame Puzzles.

## Credits
* [freeCodeCamp](https://www.freecodecamp.com)
* [qlip.in](http://qlip.in)
* [Bootstrap](http://getbootstrap.com/)
* [FontAwesome](http://fontawesome.io/)
* [Add Syntax Highlighting to your Jekyll site with Rouge](https://benhur07b.github.io/2017/03/25/add-syntax-highlighting-to-your-jekyll-site-with-rouge.html)
* [favicon.io](https://favicon.io/)
* [SEO Tutorial](https://www.youtube.com/watch?v=F2jfZ9AwwAQ&list=PL6gx4Cwl9DGBqMdJssJaiG3c9RooWQiU3)

