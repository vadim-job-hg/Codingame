import java.util.*;

class Solution {
  public static void main(String args[]) {
    final int XP_GAIN = 300;
    Scanner in = new Scanner(System.in);
    int level = in.nextInt();
    int xpNeeded = in.nextInt();
    int nbPuzzles = in.nextInt();

    int xpGained = (nbPuzzles * XP_GAIN) + (xpForLevelUp(level) - xpNeeded);

    while (xpGained >= xpForLevelUp(level)) {
      xpGained -= xpForLevelUp(level);
      ++level;
    }

    xpNeeded = xpForLevelUp(level) - xpGained;

    System.out.println(level);
    System.out.println(xpNeeded);
  }

  static int xpForLevelUp(int level) {
    return (int) Math.floor(level * Math.sqrt(level) * 10);
  }
}