import java.util.*;

class Solution {
  public static void main(String args[]) {
    Scanner in = new Scanner(System.in);
    long number = in.nextLong();
    long iterations = in.nextLong();

    for (int i = 1; i <= iterations; i++) {
      long prevNumber = number;
      number = numberOfLetters(number);
      if (prevNumber == number) // to avoid unecessary looping
        break;
    } // for

    System.out.println(number);
  } // main()

  static long numberOfLetters(long number) {
    String binary = Long.toBinaryString(number);
    long count = 0;
    for (char c : binary.toCharArray()) {
      if (c == '0')
        count += 4; // zero
      else
        count += 3; // one
    } // for
    return count;
  } // numberOfLetters()
} // Solution