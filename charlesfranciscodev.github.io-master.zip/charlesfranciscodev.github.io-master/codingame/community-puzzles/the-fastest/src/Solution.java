import java.util.Scanner;
import java.util.StringTokenizer;

class Solution {
  private enum Time {HOURS, MINUTES, SECONDS}
  private static final int ENUM_SIZE = 3;
  private static final String DELIM = ":";
  private static String currentTimeS;
  private static String fastestTimeS = "";

  private static StringTokenizer currentTimeT;
  private static StringTokenizer fastestTimeT = null;

  private static int[] currentTimeI = new int[ENUM_SIZE];
  private static int[] fastestTimeI = new int[ENUM_SIZE];

  public static void main(String args[]) {

    Scanner in = new Scanner(System.in);
    int runners = in.nextInt();

    for (int i = 0; i < runners; i++) {
      currentTimeS = in.next();
      currentTimeT = new StringTokenizer(currentTimeS, DELIM);
      if (i == 0) {
        saveFastestTime();
      } else {
        currentTimeI[Time.HOURS.ordinal()] = Integer.parseInt(currentTimeT.nextToken());
        currentTimeI[Time.MINUTES.ordinal()] = Integer.parseInt(currentTimeT.nextToken());
        currentTimeI[Time.SECONDS.ordinal()] = Integer.parseInt(currentTimeT.nextToken());
      } // else

      if (currentTimeI[Time.HOURS.ordinal()] < fastestTimeI[Time.HOURS.ordinal()]) {
        saveFastestTime();
      } else if (currentTimeI[Time.HOURS.ordinal()] == fastestTimeI[Time.HOURS.ordinal()]) {
        if (currentTimeI[Time.MINUTES.ordinal()] < fastestTimeI[Time.MINUTES.ordinal()]) {
          saveFastestTime();
        } else if (currentTimeI[Time.HOURS.ordinal()] == fastestTimeI[Time.HOURS.ordinal()]) {
          if (currentTimeI[Time.SECONDS.ordinal()] < fastestTimeI[Time.SECONDS.ordinal()]) {
            saveFastestTime();
          } // if
        } // else if
      } // else if

    } // for

    // Write an action using System.out.println()
    // To debug: System.err.println("Debug messages...");

    println(fastestTimeS);
  } // main()

  private static void saveFastestTime() {
    fastestTimeS = currentTimeS;
    fastestTimeT = new StringTokenizer(fastestTimeS, DELIM);
    fastestTimeI[Time.HOURS.ordinal()] = Integer.parseInt(fastestTimeT.nextToken());
    fastestTimeI[Time.MINUTES.ordinal()] = Integer.parseInt(fastestTimeT.nextToken());
    fastestTimeI[Time.SECONDS.ordinal()] = Integer.parseInt(fastestTimeT.nextToken());
  } // saveFastestTime()

  private static void println(String s) {
    System.out.println(s);
  } // println()
} // Solution