#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
  int width; // width of the building.
  int height; // height of the building.
  int N; // maximum number of turns before game over.
  int x; // current x position of Batman
  int y; // current y position of Batman

  cin >> width >> height; cin.ignore();
  cin >> N; cin.ignore();
  cin >> x >> y; cin.ignore(); // starting position of Batman
  cerr << "x = " << x << " ";
  cerr << "y = " << y << " " << endl;

  // Indicates the search area coordinates
  int minX = 0; // minimum x value
  int maxX = width - 1; // maximum x value
  int minY = 0; // minimum y value
  int maxY = height - 1; // maximum y value

  // game loop
  while (1) {
    string bombDir; // direction of the bombs from batman's current location (, , , , ,  or )
    cin >> bombDir; cin.ignore();

    if (bombDir == "U") { // UP
      maxY = y - 1;
      y = (minY + maxY) / 2;
    } else if (bombDir == "UR") { // UP-RIGHT
      minX = x + 1;
      maxY = y - 1;
      x = (minX + maxX) / 2;
      y = (minY + maxY) / 2;
    } else if (bombDir == "R") { // RIGHT
      minX = x + 1;
      x = (minX + maxX) / 2;
    } else if (bombDir == "DR") { // DOWN-RIGHT
      minX = x + 1;
      minY = y + 1;
      x = (minX + maxX) / 2;
      y = (minY + maxY) / 2;
    } else if (bombDir == "D") { // DOWN
      minY = y + 1;
      y = (minY + maxY) / 2;
    } else if (bombDir == "DL") { // DOWN-LEFT
      maxX = x - 1;
      minY = y + 1;
      x = (minX + maxX) / 2;
      y = (minY + maxY) / 2;
    } else if (bombDir == "L") { // LEFT
      maxX = x - 1;
      x = (minX + maxX) / 2;
    } else { // UL or UP-LEFT
      maxX = x - 1;
      maxY = y - 1;
      x = (minX + maxX) / 2;
      y = (minY + maxY) / 2;
    } // else

    cerr << "minX = " << minX << " ";
    cerr << "maxX = " << maxX << " ";
    cerr << "minY = " << minY << " ";
    cerr << "maxY = " << maxY << " " << endl;

    // the location of the next window Batman should jump to.
    cout << x << " " << y << endl;
  } // while
} // main()