#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

int getScore(char letter);

int main() {
  string bestWord = "";
  int highScore = 0;

  int nbWords; // number of words in the dictionary
  cin >> nbWords; cin.ignore();
  cerr << "number of words = " << nbWords << endl;

  vector<string> dictionary(nbWords);
  for (int i = 0; i < nbWords; ++i) {
    string word; // word in the dictionary
    getline(cin, word);
    dictionary[i] = word;
    //cerr << "word " << i << " = " << dictionary[i] << endl;
  }

  string letters; // the 7 letters available
  getline(cin, letters);
  cerr << "letters = " << letters << endl;

  unordered_map<char, int> table; // number of available letters
  for (unsigned i = 0; i < letters.size(); ++i) {
    char letter = letters[i];
    auto result = table.find(letter);
    if (result == table.end()) {
      table[letter] = 1;
    } else {
      table[letter] = result->second + 1;
    }
  }

  for (int i = 0; i < nbWords; ++i) {
    unordered_map<char, int> table2 = table;
    string entry = dictionary[i];
    bool isValid = true; // is the word valid?
    int currentScore = 0;

    // calculate the total score for one word
    for (unsigned j = 0; isValid && j < entry.size(); ++j) {
      char c = entry[j];
      auto result = table2.find(c);
      if (result == table2.end() || result->second == 0) {
        isValid = false; // unavailable letter
      } else {
        table2[c] = result->second - 1;
        currentScore += getScore(c);
      } // else
    } // for

    if (isValid && (currentScore > highScore)) {
      highScore = currentScore;
      bestWord = entry;
    } // if
  } // for

  cout << bestWord << endl;
}

int getScore(char letter) {
  unordered_map<char, int> table = {
    {'d', 2}, {'g', 2},
    {'b', 3}, {'c', 3}, {'m', 3}, {'p', 3},
    {'f', 4}, {'h', 4}, {'v', 4}, {'w', 4}, {'y', 4},
    {'j', 5},
    {'j', 8}, {'x', 8},
    {'q', 10}, {'z', 10}
  };

  auto result = table.find(letter);
  if (result != table.end())
    return result->second;

  return 1;
}