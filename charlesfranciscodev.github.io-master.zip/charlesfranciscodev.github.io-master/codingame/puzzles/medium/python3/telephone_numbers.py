class Node:
    def __init__(self, digit):
        self.digit = digit
        self.children = []

    def index(self, digit):
        for index, child in enumerate(self.children):
            if child.digit == digit:
                return index
        return -1

    def add_child(self, digit):
        child = Node(digit)
        self.children.append(child)


nb_phones = int(input())
nb_nodes = 0
root = Node(-1)

for i in range(nb_phones):
    telephone = input()
    current = root
    for char in telephone:
        digit = int(char)
        index = current.index(digit)
        if index == -1:
            current.add_child(digit)
            nb_nodes += 1
        index = current.index(digit)
        current = current.children[index]

print(nb_nodes)
